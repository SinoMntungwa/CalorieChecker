package caloriechecker;

import java.util.Scanner;

public class CalorieChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Requesting the food item
        System.out.print("Please enter food item: ");
        String word = scanner.nextLine();

        if (word.matches("[a-zA-Z]+")) {
            System.out.println("Valid input");
        } else {
            System.out.println("Invalid input: This should only contain letters");
        }

        // Requesting the calorie value
        System.out.print("Please enter calorie value: ");
        String digit = scanner.nextLine();

        if (digit.matches("\\d+")) {
            System.out.println("Valid input");
        } else {
            System.out.println("Invalid input: This should only contain digits");
        }

        scanner.close();
    }
}
